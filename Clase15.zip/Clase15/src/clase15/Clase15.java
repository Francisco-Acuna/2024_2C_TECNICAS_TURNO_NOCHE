
package clase15;

import java.util.Scanner;


public class Clase15 {

    
    public static void main(String[] args) {
        /*
        1) Una tienda ofrece un descuento del 15% sobre el total de la 
        compra durante el mes de octubre. Dado un mes y un importe, calcular
        cuál es la cantidad que se debe cobrar al cliente.
        */
        
        Scanner teclado = new Scanner(System.in);
//        
//        float descuentoOctubre = 15f;
//        float precioTotal;
//        System.out.println("Por favor ingrese un número que coresponda a"
//                + "un mes del año.");
//        int mes = teclado.nextInt();
//        
//        
//        while(mes<1 || mes>12){
//            System.out.println("Error, el mes debe ser un número entre 1 y 12");
//            System.out.println("Ingrese un número que corresponda a un mes"
//                    + "del daño");
//            mes = teclado.nextInt();
//        }
//        
//        System.out.println("El mes es válido");
//        System.out.println("Por favor, ingrese el precio");
//        float precio = teclado.nextFloat();
//        
//        if(mes==10){
//            System.out.println("Este mes ofrecemos el 15% de descuento sobre"
//                    + " el importe de sus compras");
//            precioTotal = precio - (precio * descuentoOctubre) / 100;
//            System.out.println("Cantidad a cobrar al cliente: " + precioTotal);
//        }else{
//            System.out.println("Cantida a cobrar al cliente: " + precio);
//        }
//        
//        System.out.println("Gracias por su compra, hasta pronto!");
        
        /*
        2) Crear un programa que pida al usuario un número y un símbolo, y 
        dibuje un cuadrado usando ese símbolo. El cuadrado tendrá el tamaño
        que ha indicado el usuario. Por ejemplo, si el usuario introduce 4 
        como tamaño y * como símbolo, deberá escribirse algo como:
        ****
        ****
        ****
        **** 

        */
        
//        System.out.println("Por favor ingrese un número");
//        int numero = teclado.nextInt();
//        teclado.nextLine();
//        System.out.println("Ahora ingrese un símbolo");
//        char simbolo = teclado.next().charAt(0);
//        
//        for(int i=0; i<numero; i++){
//            for(int j=0; j<numero; j++){
//                System.out.print(simbolo);
//            }
//            System.out.println("");
//        }
        
        /*
        3) Se pide representar el algoritmo que nos calcule la suma de los 
        N primeros números naturales. N se leerá por teclado. Ejemplo, si 
        ingresamos 4, hacer: 1+2+3+4 = 10
        */
        
//        int suma = 0;
//        System.out.println("Por favor ingrese un número");
//        int numero = teclado.nextInt();
//        
//        for(int i=1; i<=numero; i++){
//            if(i<numero){
//                System.out.print(i+"+"); 
//                suma+=i;                
//            }else {
//                System.out.print(i);
//                suma+=i;
//            }
//        }
//        
//        System.out.println(" = " + suma);
        
        /*
        4) Crear un programa que visualice la cuenta de los números que 
        son múltiplos de 2 o de 3 que hay entre 1 y 100. 
        */

//        int contador = 0;
//        for(int i=1; i<=100; i++){
//            if(i%2==0 || i%3==0) contador++;            
//        }
//        
//        System.out.println("La cantidad de múltiplos de 2 y de 3 es: " + contador);

        /*
        5) Desarrollar un programa que permita ingresar un número N. Acto 
        seguido, permitir ingresar N números. La computadora muestra cuál 
        fue el mayor y en qué orden apareció. Ejemplo: Se ingresa 5, luego 
        4 8 6 7 5, la computadora muestra: "El mayor es el 8 en la 2° 
        posición".
        */
        
        System.out.println("Ingrese un número");
        int numero = teclado.nextInt();
        int numeroMayor = Integer.MIN_VALUE;
        int posicion = 1;
        
        for(int i=1; i<=numero; i++){
            System.out.println("Ingrese el " + i + "° número");
            int numeroIngresado = teclado.nextInt();
            
            if(numeroIngresado>numeroMayor){
                numeroMayor = numeroIngresado;
                posicion = i;
            }
        }
        
        System.out.println("El mayor número fue el " + numeroMayor);
        System.out.println("Que se encontró en la posición " + posicion);
        
    }
    
}
