
package clase19;


public class Clase19 {


    public static void main(String[] args) {
        //si tuviéramos que guardar varios valores enteros en variables
        int numero1 = 10;
        int numero2 = 30;
        int numero3 = 76;
        int numero4 = 125;
        
        /*
        Podemos generar un conjunto de variables que tengan un mismo nombre 
        que las agrupe a todas. 
        Podemos acceder a cada variable por medio del índice.
        El índice comienza en cero.
        Optimizamos la lectura de la información para acceder por un mismo
        nombre a distintas variables y no por el nombre de cada una de ellas.
        */
        
        System.out.println("Arreglos, Arrays o vectores");
        
        /*
            tipoDeDato[] identificador; --> declaración
            tipoDeDato identificador[]; --> declaración
            identificador = new tipoDeDato[n]; --> definición de longitud
            la longitud es la cantidad de elementos que tendrá
        */
        
        float[] temperaturas; // declaración
        temperaturas = new float[10]; //defino la longitud en 10
        float temperaturas2[]; //declaración
        temperaturas2 = new float[12]; //defino la longitud en 12
        String[] nombres = new String[5];
        //declaración del arreglo y definición de longitud
        
        //asignación de valores a un arreglo
        temperaturas[0] = 25.32f;
        temperaturas[1] = 12.56f;
//        temperaturas[2] = "Jose"; error, no es del mismo tipo de dato
        
        nombres[3] = "Juan";
//        nombres[5] = "María"; error, no existe el índice 5 para una longitud de 5

    
        
        
        
        
        
        
        
        
    }
    
}
