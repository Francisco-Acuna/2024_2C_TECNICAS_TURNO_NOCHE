/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase10;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*
        Crear un programa que simule la petici�n de
        una opci�n seg�n el siguiente men� y muestre
        en pantalla que ha ingresado a la opci�n
        seleccionada con las opciones siguientes:
        
        �Gracias por contactarte con nosotros!
        �En qu� podemos ayudarte?
        A) Documentaci�n
        B) Cotizaci�n
        C) Asistencia
        D) Siniestros
        E) Informaci�n de Pagos
        F) Otras Consultas
        G) Anulaci�n
        Escribe la letra de la opci�n seleccionada.
        
        Debe mostrarse:
        Has elegido Documentaci�n (o la opci�n que haya elegido)
        */
        
        Scanner teclado = new Scanner(System.in);
        
        String opcion;
        System.out.println("�Gracias por contactarte con nosotros!\n" +
"        �En qu� podemos ayudarte?\n" +
"        A) Documentaci�n\n" +
"        B) Cotizaci�n\n" +
"        C) Asistencia\n" +
"        D) Siniestros\n" +
"        E) Informaci�n de Pagos\n" +
"        F) Otras Consultas\n" +
"        G) Anulaci�n\n" +
"        Escribe la letra de la opci�n seleccionada.");
        
        opcion = teclado.next().toUpperCase();
        
        switch(opcion){
            case "A": System.out.println("Has elegido Documentaci�n"); break;
            case "B": System.out.println("Has elegido Cotizaci�n"); break;
            case "C": System.out.println("Has elegido Asistencia"); break;
            case "D": System.out.println("Has elegido Siniestro"); break;
            case "E": System.out.println("Has elegido Informaci�n de Pagos"); break;
            case "F": System.out.println("Has elegido Otras Consultas"); break;
            case "G": System.out.println("Has elegido Anulaci�n"); break;
            default: System.out.println("Opci�n incorrecta");
        }
        
        switch(opcion){
            case "A" -> System.out.println("Has elegido Documentaci�n");
            case "B" -> System.out.println("Has elegido Cotizaci�n");
            case "C" -> System.out.println("Has elegido Asistencia");
            case "D" -> System.out.println("Has elegido Siniestro");
            case "E" -> System.out.println("Has elegido Informaci�n de Pagos");
            case "F" -> System.out.println("Has elegido Otras Consultas");
            case "G" -> System.out.println("Has elegido Anulaci�n");
            default -> System.out.println("Opci�n incorrecta");
        }
        
         /*
        Solicitar al usuario que ingrese dos n�meros.
        Luego ofrecerle un men� con las siguientes opciones:
        1-suma 2-resta 3-multiplicaci�n 4-divisi�n
        Finalmente, mostrar el resultado de la operaci�n
        aritm�tica elegida.
        */
         
         System.out.println("Ingrese dos n�meros");
         int nro1 = teclado.nextInt();
         int nro2 = teclado.nextInt();
         
         System.out.println("Ingrese una opci�n:\n 1-suma 2-resta 3-multiplicaci�n 4-divisi�n");
         int resultado = teclado.nextInt();
         switch (resultado) {
            case 1: System.out.println("El resultado de la suma de los n�meros es: " + (nro1+nro2)); break;
            case 2: System.out.println("El resultado de la resta de los n�meros es: " + (nro1-nro2)); break;
            case 3: System.out.println("El resultado de la multiplicaci�n de los n�meros es: " + (nro1*nro2)); break;
            case 4: 
                if(nro2==0){
                    System.out.println("No se puede dividir por 0");                    
                }else{
                    System.out.println("El resultado de la divisi�n de los n�meros es: " + (nro1/nro2));
                } break;
            default: System.out.println("Opci�n inv�lida");
        }
         
        switch (resultado) {
            case 1 -> System.out.println("El resultado de la suma de los n�meros es: " + (nro1+nro2));
            case 2 -> System.out.println("El resultado de la resta de los n�meros es: " + (nro1-nro2));
            case 3 -> System.out.println("El resultado de la multiplicaci�n de los n�meros es: " + (nro1*nro2));
            case 4 -> { 
                if(nro2==0){
                    System.out.println("No se puede dividir por 0");                    
                }else{
                    System.out.println("El resultado de la divisi�n de los n�meros es: " + (nro1/nro2));
                }
            }
            default -> System.out.println("Opci�n inv�lida");
        } 
        
    }
    
}
