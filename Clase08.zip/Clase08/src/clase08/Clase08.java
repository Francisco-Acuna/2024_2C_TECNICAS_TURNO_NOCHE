/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase08;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase08 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        Crear un programa que solicite al usuario que ingrese su primer 
        nombre y su apellido.
        Luego mostrarlo por consola, por separado, indicando cu�l es su 
        apellido primero y luego debajo entre comillas dobles, su nombre.
        Nombre y apellido deben ir con la primer letra en may�scula.
        Vamos a suponer, para este ejercicio, que el usuario tiene un solo 
        nombre y un solo apellido.
        */
        
        
        Scanner teclado = new Scanner(System.in);
        
//        System.out.println("Ingrese su primer nombre y apellido a continuaci�n:");
//        String nombre = teclado.next();
//        String apellido = teclado.next();
//        
//        System.out.println("Su apellido es: " + 
//                apellido.toUpperCase().charAt(0) + 
//                apellido.substring(1).toLowerCase());
//        
//        System.out.println("Su nombre es: " + '"' + 
//                nombre.toUpperCase().charAt(0) + 
//                nombre.substring(1).toLowerCase() + '"');
        
        System.out.println("\n****************************\n");
        
        System.out.println("Estructuras condicionales");
        
        System.out.println("**Estructura if**");
        
        int nro1 = 10;
        int nro2 = 20;
        
        if(nro1 > nro2){
            System.out.println("El nro1 es mayor que el nro2.");
        }
        
        System.out.println("Fin de la estructura if");
        
        if(nro1 == 10){
            System.out.println("El nro1 es igual a 10");
        }
        
        boolean log1 = true;
        
        if(log1){ //las variables booleanas no se comparan con == true
            System.out.println("La variable log1 es verdadera");
        }
        
        if(nro1 != nro2 && log1){
            System.out.println("El nro1 es distinto al nro2 y log1 es verdadera");
        }
        
        if(nro1 > 1) System.out.println("El nro1 es mayor a 1");
        //if en l�nea, si solo se ejecutar� una �nica sentencia en el bloque
        //if, se puede escribir todo en l�nea sin utilizar las llaves
        
        System.out.println("\n**Estructura if-else**");
        
        if(nro1 > nro2){
            System.out.println("El nro1 es mayor que el nro2");
        }else{
            System.out.println("El nro1 no es mayor que el nro2");
        }
        
        //en l�nea:
        if(nro1 > nro2) System.out.println("El nro1 es mayor que el nro2");
        else System.out.println("El nro1 no es mayor que el nro2");
        
        System.out.println("\n**Estructuras if-else if-else**");
        
        if(nro1 > nro2){
            System.out.println("El nro1 es mayor que el nro2");
        }else if(nro2 > nro1){
            System.out.println("El nro2 es mayor que el nro1");
        }else{
            System.out.println("Ambos n�meros son iguales.");
        } 
        
        //simulaci�n de jubilaci�n
        //hombre se puede jubilar a los 65 a�os
        //mujer se puede jubilar a los 60 a�os
        
        int edad = 18;
        String sexo = "mujer";
        
        if(edad >= 60 && sexo.equals("mujer")){
            System.out.println("Puede jubilarse.");
        }else if(edad >= 65 && sexo.equals("hombre")){
            System.out.println("Puede jubilarse.");
        }else{
            System.out.println("No se puede jubilar");
        }
        
        if(edad>=60 && sexo.equals("mujer") || edad>=65 && sexo.equals("hombre")){
            System.out.println("Puede jubilarse");
        }else{
            System.out.println("No se puede jubilar");
        }
        
        System.out.println("\n**Estructura if-else anidado**");
        
        String usuario = "pepito";
        String clave = "1234";
        
        if(usuario.equals("pepito")){
            if(clave.equals("1234")){
                System.out.println("Bienvenido Pepito!");
            }else{
                System.out.println("Clave es incorrecta");
            }
        }else{
            System.out.println("Usuario incorrecto");
        }
        
        edad = 18;
        boolean tienePasaporte = true;
        
        if(tienePasaporte){
            if(edad >= 18){
                System.out.println("Usted puede viajar.");
            }else{
                System.out.println("Usted debe viajar acompa�ado de un mayor.");
            }
        }else{
            System.out.println("Usted no puede viajar.");
        }
        
        
    }
    
}
