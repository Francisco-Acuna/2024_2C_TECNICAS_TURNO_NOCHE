
package clase18;

import java.util.Scanner;


public class Clase18 {


    public static void main(String[] args) {
        
        /*
        Ejercicios funciones:
        1. crear una función que devuelva la cantidad de vocales de una palabra
        2. crear una función que indique si un número es múltiplo de 3
        3. crear una función que aplique %50 de premio si el ingreso es de más de 35.000
        */
        
        Scanner teclado = new Scanner(System.in);
        
//        System.out.println("Ingrese una palabra");
//        String palabra = teclado.next();
//        teclado.nextLine();
//        int cantidadVocales = contarVocales(palabra.toLowerCase());
//        System.out.println("La cantidad de vocales es: " + cantidadVocales);


//        System.out.println("Por favor ingrese un número a verificar si el "
//                + "mismo es múltiplo de 3");
//        int numero = teclado.nextInt();
//        System.out.println("El resultado para " + numero + " es: " + esMultiploDe3(numero));
        
//
//        System.out.println("Digite el ingreso");
//        float ingreso = teclado.nextFloat();
//        float valorComision = aplicarPremio(ingreso, 50);
//        System.out.println("Su premio o comisión es de: " + valorComision);
        
        /*
        Ejercicios procedimientos:
        1. Crear un procedimiento que calcule el área del triángulo y lo informe 
        por pantalla
        2. Crear un procedimiento que muestre por pantalla el valor del IVA de 
        un producto ingresado como parámetro
	3. Crear un procedimiento que muestre por pantalla la cantidad de números 
        impares que ingresa el usuario y lo informe por pantalla	
        */
        
//        System.out.println("Ingrese la base del triángulo");
//        double baseTriangulo = teclado.nextDouble();
//        System.out.println("Ingrese la altura del triángulo");
//        double alturaTriangulo = teclado.nextDouble();
//        calcularAreaTriangulo(baseTriangulo, alturaTriangulo);
        
//        float porcentaje = 21;
//        System.out.println("Ingrese el valor del producto");
//        float valor = teclado.nextFloat();
//        calcularIva(valor, porcentaje);

//        contadorImpares();

        /*
        Crear un programa que reciba 3 parámetros y calcule la suma, resta, 
        multiplicación, división y el resto de dos números con decimales. 
        Las consignas para lograrlo son:
        * Debe crear un procedimiento, que reciba los 3 parámetros: 2 números con
        decimales y el carácter de operación.
        * Debe crear las funciones de las operaciones que retornen un número 
        con decimales.
        * Debe mostrar por consola un mensaje que indique el resultado y la 
        operación realizada
        */
        
        System.out.println("Ingrese el primer número");
        float numero1 = teclado.nextFloat();
        System.out.println("Ingrese el segundo número");
        float numero2 = teclado.nextFloat();
        System.out.println("Ingrese el caracter de la operación:");
        char operador = teclado.next().charAt(0);
        
        calcularOperacion(numero1, numero2, operador);

    }
    
    public static int contarVocales(String palabra){
        int cantidadVocales = 0;
        for (int i = 0; i < palabra.length(); i++) {
            char vocal = palabra.charAt(i);
            if(vocal=='a' || vocal=='e' || vocal=='i' || vocal=='o' || vocal=='u'
                    || vocal=='á' || vocal=='é' || vocal=='í' || vocal=='ó' || vocal=='ú'
                    || vocal=='ü'){
                cantidadVocales++;
            }
        }
        return cantidadVocales;
    }
    
    
    public static boolean esMultiploDe3(int numero){
        return numero % 3 == 0;
    }
    
    public static float aplicarPremio(float ingreso, float premio){
        float resultado = ingreso;
        if(ingreso > 35000) resultado += ingreso / 100 * premio;
        return resultado;
    }
    
    public static void calcularAreaTriangulo(double base, double altura){
        double area = (base * altura) / 2;
        System.out.println("El área del triángulo es: " + area);
    }
    
    public static void calcularIva(float valor, float porcentaje){
        float iva = (valor * porcentaje) / 100;
        System.out.println("El IVA del producto es: " + iva);
    }    
    
    public static void contadorImpares(){
        Scanner teclado = new Scanner(System.in);
        int numero;
        int impares = 0;
        System.out.println("Bienvenido. Se contarán la cantidad de ingresos de números"
                + "impares hasta que usted digite cero.");
        do {
            System.out.println("Digite un valor");
            numero = teclado.nextInt();
            if(numero%2!=0) impares++;
        } while (numero!=0);
        
        System.out.println("La cantidad de números impares digitados es igual a: " + impares);
    }
    
    public static void calcularOperacion(float numero1, float numero2, char operador){
        float resultado = 0;
        String mensaje;
        switch(operador){
            case '+': 
                resultado = sumar(numero1, numero2);
                mensaje = "Suma"; break;
            case '-':
                resultado = restar(numero1, numero2);
                mensaje = "Resta"; break;
            case '*':
                resultado = multiplicar(numero1, numero2);
                mensaje = "Multiplicar"; break;
            case '/':
                if(numero2!=0){
                    resultado = dividir(numero1, numero2);
                    mensaje = "Dividir";
                }else{
                    mensaje = "No se puede dividir por cero, animal!";
                }  break;
            case '%':
                if(numero2!=0){
                    resultado = calcularResto(numero1, numero2);
                    mensaje = "Cálculo de resto";
                }else{
                    mensaje = "No se puede dividir por cero, animal!";
                }  break;
            default: mensaje="Operación no válida";
        }
        System.out.println("El resultado fue: " + resultado);
        System.out.println("La operación fue: " + mensaje);
    }
    
    public static float sumar(float numero1, float numero2){
        return numero1 + numero2;
    }
    
    public static float restar(float numero1, float numero2){
        return numero1 - numero2;
    }
    
    public static float multiplicar(float numero1, float numero2){
        return numero1 * numero2;
    }
    
    public static float dividir(float numero1, float numero2){
        return numero1 / numero2;
    }
    
    public static float calcularResto(float numero1, float numero2){
        return numero1 % numero2;
    }
    
}
