

package clase06;


public class ClaseString {
    public static void main(String[] args) {
        /*
        Convenciones de escritura
        camel case -> estoEsUnaFraseEnCamelCase (lower camel case)
        pascal case -> EstoEsUnaFraseEnCamelCase (upper camel case)
        snake case -> esto_es_una_frase_en_camel_case
        */
        
        System.out.println("** Clase String **");
        
        //la clase String representa un vector de caracteres
        
        //hay varias maneras de poder crear un objeto de String
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";
        
        //comparar cadenas de caracteres
        //si utilizamos el operador == va a comprobar que ocupen
        //el mismo lugar en memoria
        System.out.println(texto3 == "hola"); //true
        System.out.println(texto2 == "hola"); //false
        
        //para comparar cadenas de caracteres teniendo en cuenta
        //su contenido utilizamos los m�todos
        //.equals() .equalsIgnoreCase()
        //devuelve un booleano indicando si la cadena es igual
        //a otra cadena pasada por par�metro (valor de entrada)
        System.out.println(texto3.equals("hola")); //true
        System.out.println(texto2.equals("hola")); //true
        System.out.println(texto2.equals(texto3)); //true
        System.out.println(texto2.equals("Hola")); //falso
        //para ignorar las may�sculas y min�sculas utilizamos
        //.equalsIgnoreCase()
        System.out.println(texto2.equalsIgnoreCase("Hola"));//true
        
        //.contains()
        //devuelve un booleano que indica si la cadena contiene
        //la subcadena que pasamos por par�metro
        System.out.println(texto1.contains("caracteres"));//false
        System.out.println(texto2.contains("ol"));//true
        System.out.println(texto2.contains("lo"));//false
        
        //.length()
        //devuelve la longitud de la cadena, es decir, la cantidad de caracteres
        //que tiene
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4
        
        //.isEmpty()
        //indica si la cadena est� vac�a, es decir, si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); //false
        
        // a partir del JDK 11 aparece el m�todo .isBlank()
        //este m�todo indica si la cadena est� vac�a, o si solo hay espacios
        //en blanco, o si solo tiene tabulaciones o saltos de l�nea
        String texto4 = "   ";
        System.out.println(texto4.isEmpty()); //false
        System.out.println(texto4.isBlank()); //true
        
        //.charAt()
        //devuelve el caracter del �ndice pasado como par�metro
        System.out.println(texto1.charAt(7)); //d
        //System.out.println(texto2.charAt(4)); //error, �ndice fuera de rango

        //.indexOf()
        //devuelve el �ndice de la primera ocurrencia de la subcadena
        //si no encuentra la subcadena, devuelve -1
        System.out.println(texto1.indexOf("texto")); //-1
        System.out.println(texto1.indexOf("Texto")); //10
        
        //.trim()
        //quita los espacios de adelante y de atr�s
        System.out.println("   Buenas noches   ");
        System.out.println("   Buenas noches   ".trim());
        
        //.startsWith() .endsWith()
        //devuelven un booleano indicando si la cadena empieza o finaliza
        //con la subcadena que se pasa como par�metro
        System.out.println(texto1.endsWith("Texto")); //false
        System.out.println(texto1.endsWith("exto!")); //true
        System.out.println(texto2.startsWith("ola")); //false
        System.out.println(texto2.startsWith("hola")); //true
        System.out.println(texto2.endsWith("hola")); //true
        
        //m�todos replace
        //.replace()
        //reemplaza un caracter por otro en toda la cadena
        System.out.println(texto1.replace('e', 'i')); 
        //tambi�n reemplaza cadenas de caracteres
        System.out.println(texto1.replace("Texto", "caracteres"));
        System.out.println(texto1);
        //.replaceFirst()
        //reemplaza la primera vez que aparezca la subcadena
        String texto5 = "manzana, manzana, naranja";
        System.out.println(texto5.replaceFirst("manzana", "banana"));
        //.replaceAll()
        //reemplaza todas las veces que aparezca la subcadena
        System.out.println(texto5.replaceAll("manzana", "banana"));
        
        String texto6 = "Mi n�mero de contacto personal es 011-4656-9988"
                + " y el n�mero de mi trabajo es 011-2323-8877.";
        
        System.out.println(texto6.replaceAll("\\d{3}-\\d{4}-\\d{4}", "HIDDEN INFORMATION"));
        
                
                
    }
}
