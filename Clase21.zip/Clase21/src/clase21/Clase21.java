
package clase21;

import java.util.Scanner;


public class Clase21 {


    public static void main(String[] args) {
        /*
        crear un vector de 10 posiciones
        pedirle al usuario que cargue 10 valores para ese vector
        indicar cuántos números pares y cuántos impares hay
        indicar cuántas veces apareció el número 2
        */
        
        resolverEjercicioUno();
        
    }
    
    public static void resolverEjercicioUno(){
        int vector[] = crearVectorDeEnteros(10);
        contarNumerosPares(vector);
        int cantidad = contarAparicionesDeNumero(vector, 2);
        System.out.println("El numero 2 apareció " + cantidad + " veces.");
    }

    public static int[] crearVectorDeEnteros(int longitud){
        int[] numerosEnteros = new int[longitud];
        Scanner teclado = new Scanner(System.in);
        System.out.println("A continuación ingrese los " + longitud + 
                " números enteros:");
        for(int i=0; i<longitud; i++){
            System.out.println("Ingrese el número en el lugar: " + (i+1));
            numerosEnteros[i] = teclado.nextInt();            
        }
        return numerosEnteros;
    }
    
    public static void contarNumerosPares(int[] arreglo){
        int cantidadDeNumerosPares = 0;
        int cantidadDeNumerosImpares = 0;
        for(int a:arreglo) {
            if(a%2==0){
                cantidadDeNumerosPares++;
            }else{
                cantidadDeNumerosImpares++;
            }
        }
        System.out.println("La cantidad de números pares es: " + cantidadDeNumerosPares);
        System.out.println("La cantidad de números impares es: " + cantidadDeNumerosImpares);
    }
    
    /**
     * Este método cuenta la cantidad de apariciones del número que se ingresa
     * como parámetro.Dentro del arreglo que también se ingresa por parámetro
     * @return 
     */
    public static int contarAparicionesDeNumero(int[] arreglo, int numero){
        int cantidadDeApariciones = 0;
        for(int a:arreglo) if(a==numero) cantidadDeApariciones++;
        return cantidadDeApariciones;
    }
    
}
