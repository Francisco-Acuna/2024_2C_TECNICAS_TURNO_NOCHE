

package clase05;


public class ClaseString {
    public static void main(String[] args) {
        /*
        Convenciones de escritura
        camel case -> estoEsUnaFraseEnCamelCase (lower camel case)
        pascal case -> EstoEsUnaFraseEnCamelCase (upper camel case)
        snake case -> esto_es_una_frase_en_camel_case
        */
        
        System.out.println("** Clase String **");
        
        //la clase String representa un vector de caracteres
        
        //hay varias maneras de poder crear un objeto de String
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";
        
        //comparar cadenas de caracteres
        //si utilizamos el operador == va a comprobar que ocupen
        //el mismo lugar en memoria
        System.out.println(texto3 == "hola"); //true
        System.out.println(texto2 == "hola"); //false
        
        //para comparar cadenas de caracteres teniendo en cuenta
        //su contenido utilizamos los m�todos
        //.equals() .equalsIgnoreCase()
        //devuelve un booleano indicando si la cadena es igual
        //a otra cadena pasada por par�metro (valor de entrada)
        System.out.println(texto3.equals("hola")); //true
        System.out.println(texto2.equals("hola")); //true
        System.out.println(texto2.equals(texto3)); //true
        System.out.println(texto2.equals("Hola")); //falso
        //para ignorar las may�sculas y min�sculas utilizamos
        //.equalsIgnoreCase()
        System.out.println(texto2.equalsIgnoreCase("Hola"));//true
        
        //.contains()
        //devuelve un booleano que indica si la cadena contiene
        //la subcadena que pasamos por par�metro
        System.out.println(texto1.contains("caracteres"));//false
        System.out.println(texto2.contains("ol"));//true
        System.out.println(texto2.contains("lo"));//false
        
        
        
    }
}
