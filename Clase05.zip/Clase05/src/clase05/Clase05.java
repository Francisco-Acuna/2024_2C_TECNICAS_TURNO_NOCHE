
package clase05;

import java.text.DecimalFormat;




public class Clase05 {


    public static void main(String[] args) {
        /*
        1-
        Dados num1=5, num2=10 y num3=20. Informar:
        a) num1+num2
        b) num3-num1
        c) num1*num3
        d) num3/num2
        */
        
        int num1=5, num2=10, num3=20;
        
        System.out.println("El resultado de num1 + num2 es: " + (num1 + num2));
        System.out.println("El resultado de num3 - num1 es: " + (num3 - num1));
        System.out.println("El resultado de num1 * num3 es: " + (num1 * num3));
        System.out.println("El resultado de num3 / num2 es: " + (num3 / num2));
        
        System.out.println("");
        System.out.println("********************");
        System.out.println("");
        
        /*
        2-
        Dados nro_1=10, nro_2=20 y nro_3=30. Informar :
        a) El total de la suma de todas las variables
        b) El promedio
        c) El resto entre nro2 y nro1
        */
        
        int nro_1=10, nro_2=20, nro_3=30;
        int sumaTotal = nro_1 + nro_2 + nro_3;
        int promedio = sumaTotal / 3;
        int resto = nro_2 % nro_1;
        
        System.out.println("La suma total de todas las variables es: " 
                + sumaTotal);
        System.out.println("El promedio es: " + promedio);
        System.out.println("El resto entre nro_2 y nro_1 es: " + resto);
        
        System.out.println("");
        System.out.println("********************");
        System.out.println("");
        
        /*
        3-
        Declarar dos variables n1=5 y n2=10.
        Utilizando concatenaci�n entre las variables y los literales, mostrar en pantalla la siguiente
        expresi�n:
        n1 es igual a 5, n2 es igual a 10 y n1 m�s n2 es igual a 15.
        */
        
        int n1=5, n2=10;
        int total=n1+n2;
        System.out.println("n1 es igual a " + n1 + ", n2 es igual a " + 
                n2 + " y n1 m�s n2 es igual a " + (n1 + n2) + "." );
        
        System.out.println("");
        System.out.println("********************");
        System.out.println("");
        
        /*
        4-
        Haciendo uso de la constante IVA=21, calcular el precio con IVA de 
        los siguientes productos e informar:
        a) remera:$59.90
        b) pantal�n:$99.90
        c) campera:$149.90
        */
        
        final float IVA = 21;
        float remera = 59.90f;
        float pantalon = 99.90f;
        float campera = 149.90f;
        
        float valorIvaRemera = remera / 100 * IVA;
        float valorIvaPantalon = pantalon / 100 * IVA;
        float valorIvaCampera = campera / 100 * IVA;
        
        System.out.println("El precio total con IVA de la remera: " +
                (remera + valorIvaRemera));
        System.out.println("El precio total con IVA de la pantalon: " +
                (pantalon + valorIvaPantalon));
        System.out.println("El precio total con IVA de la campera: " +
                (campera + valorIvaCampera));
        
        
        DecimalFormat df = new DecimalFormat("#.##");
        
        float remeraConIva = valorIvaRemera + remera;
        
        System.out.println(remeraConIva);
        
        String precioRedondeado = df.format(remeraConIva);
        
        System.out.println("$" + precioRedondeado);
        
    }
    
}
