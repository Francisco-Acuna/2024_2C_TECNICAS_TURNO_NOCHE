/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase13;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        
        /*
        String token="123456";
        String usuario ="pepe";
        String clave ="Pepe123";
        int intentos = 1;
        int intentoMax = 3;
        String respuesta = "";
        
         
        String claveIngresada;
        String tokenIngresado;
        String usuarioIngresado;
         
         
         
                  
         do {
            System.out.println("bienvenido al home banking, su token es: " + token);
            System.out.println("Ingrese usuario");
            usuarioIngresado = teclado.next().toLowerCase();
            System.out.println("Ingrese contrase�a");
            claveIngresada = teclado.next();
            System.out.println("Ingrese token de 6 digitos");
            tokenIngresado = teclado.next();
            
            if ((tokenIngresado.equals(token)) && (usuarioIngresado.equals(usuario)) && (claveIngresada.equals(clave))){
             System.out.println("ingreso aprobado"); break;
            }else if(intentos < intentoMax){
                    if(!usuarioIngresado.equals(usuario)){ 
                        System.out.println("error, usuario incorrecto: " + intentos + " �desea continuar intentando?");
                        respuesta = teclado.next().toLowerCase();

                    }else if(!claveIngresada.equals(clave)){ 
                        System.out.println("error, clave incorrecta: " + intentos + " �desea continuar intentando?");
                        respuesta = teclado.next().toLowerCase();

                    }else if(!tokenIngresado.equals(token)){ 
                        System.out.println("error, token incorrecto: " + intentos + " �desea continuar intentando?");
                        respuesta = teclado.next().toLowerCase();
                    }            
            }
            
            while (!respuesta.equals("si") && !respuesta.equals("no")){
             System.out.println("escriba si o no");
             respuesta = teclado.next().toLowerCase();
            }
            
            if(respuesta.equals("no")){
                System.out.println("Gracias vuelva prontos!"); break;
                    
//            }else if (!respuesta.equals("si")){
//                    System.out.println("error, intento n�mero: " + intentos + "�desea continuar intentando?");
//                   respuesta = teclado.next().toLowerCase();
                            
            }else if (intentos == intentoMax) {System.out.println("error en los 3 intentos, debe dirigirse a la sucursal"
                 + " del banco m�s cercana para poder desbloquear sus credenciales");
            }            
            intentos ++; 
         }while (intentos <4 && respuesta.equalsIgnoreCase("si"));
                   
         */
        
    }
    
}
