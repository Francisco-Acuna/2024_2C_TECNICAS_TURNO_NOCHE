/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase09;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase09 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        /*
	Ejercicio1:
        Seg�n la edad de una persona mostraremos los siguientes mensajes:
        menos de 12 a�os: "eres un ni�o"
        entre 12 y 17 a�os: "eres un adolescente"
        entre 18 y 39 a�os: "eres joven" 
        entre 40 y 70: "eres maduro"
        71 para arriba: "eres anciano"
         */
        Scanner teclado = new Scanner(System.in);

//        int edad;
//        System.out.println("Ingrese su edad:");
//        edad = teclado.nextInt();
//
//        if (edad < 12) {
//            System.out.println("Eres un ni�o");
//        } else if (edad <= 17) {
//            System.out.println("Eres un adolescente");
//        } else if (edad <= 39) {
//            System.out.println("Eres joven");
//        } else if (edad <= 70) {
//            System.out.println("Eres maduro");
//        } else {
//            System.out.println("Eres anciano");
//        }

        /*
        Ejercicio 2:
        Dada la siguiente tabla del tiempo, hacer un
        programa que indique qu� puede hacer una
        persona con dicho pron�stico:
        
        Temperatura     Tiempo      Sugerencia
        > 25�           Soleado     Caminar y tomar sol
        > 15� y <=25�   Soleado     Caminar
        <=15�           Soleado     Caminar con campera
        <10�            Lluvia      Quedarse en casa o salir con paraguas y campera
        <10�            Nieve       Esquiar
        
        Luego pedirle al usuario que ingrese una temperatura y una condici�n
        del tiempo v�lida (Soleado, lluvia o nieve) e indicarle la sugerencia.
         */
//        System.out.println("Ingrese la temperatura actual:");
//        int temperatura = teclado.nextInt();
//        System.out.println("Ingrese una condici�n del tiempo");
//        System.out.println("(soleado, lluvia, nieve)");
//        String tiempo = teclado.next();
//        if(temperatura>25 && tiempo.equalsIgnoreCase("soleado")){
//            System.out.println("Sugerencia: Caminar y tomar sol.");
//        }else if(temperatura>15 && temperatura<=25 && tiempo.equalsIgnoreCase("soleado")){
//            System.out.println("Sugerencia: caminar");
//        }else if(temperatura<=15 && tiempo.equalsIgnoreCase("soleado")){
//            System.out.println("Sugerencia: caminar con campera");
//        }else if(temperatura<10 && tiempo.equalsIgnoreCase("lluvia")){
//            System.out.println("Sugerencia: quedarse en casa o salir con paraguas y campera");
//        }else if(temperatura<10 && tiempo.equalsIgnoreCase("nieve")){
//            System.out.println("Sugerencia: esquiar");
//        }
//        System.out.println("Ingrese una condici�n del tiempo v�lida:");
//        System.out.println("(soleado, lluvia, nieve)");
//        String tiempo = teclado.nextLine();
//        System.out.println("Ingrese una temperatura:");
//        int temperatura = teclado.nextInt();



//        if(tiempo.equalsIgnoreCase("soleado") || tiempo.equalsIgnoreCase("lluvia") || tiempo.equalsIgnoreCase("nieve")){ 
//            if(tiempo.equalsIgnoreCase("soleado")){
//                if(temperatura>25) System.out.println("Sugerencia: Caminar y tomar sol");
//                else if(temperatura>=15) System.out.println("Sugerencia: caminar");
//                else System.out.println("Sugerencia: caminar con campera");
//            }else if(tiempo.equalsIgnoreCase("lluvia")){
//                if(temperatura<10) System.out.println("Sugerencia: quedarse en casa o salir con paraguas y campera");
//            }else if(tiempo.equalsIgnoreCase("nieve")){
//                if(temperatura<10) System.out.println("Sugerencia: esquiar");
//            }  
//        }else System.out.println("La condici�n del tiempo ingresado no es v�lida");
            

        /*
        Ejercicio 3:
        Solicitar al usuario que ingrese 3 n�meros. 2 positivos y 1 negativo
        (en cualquier orden).
        Luego, informar por pantalla la multiplicaci�n de los n�meros que son positivos
        */
          
        System.out.println("Ingrese tres n�meros, dos positivos y uno negativo.");
        System.out.println("En cualquier orden.");
        System.out.println("A continuaci�n ingrese el primer n�mero");
        int num1 = teclado.nextInt();
        System.out.println("Ingrese el segundo n�mero:");
        int num2 = teclado.nextInt();
        System.out.println("Ingrese el tercer n�mero:");
        int num3 = teclado.nextInt();
        int resultado;
        
        // el siguiente ejemplo no contempla que no se cumpla la consigna
        if(num1<0 && num2 >=1 && num3>=1){
            resultado = num2 * num3;
            System.out.println("El resultado de la multiplicaci�n de los dos "
                    + "n�meros positivos es: " + resultado);
        }else if(num1>=1 && num2<0 && num3>=1){
            resultado = num1 * num3;
            System.out.println("El resultado de la multiplicaci�n de los dos "
                    + "n�meros positivos es: " + resultado);
        }else {
            resultado = num1 * num2;
            System.out.println("El resultado de la multiplicaci�n de los dos "
                    + "n�meros positivos es: " + resultado);
        }
        
        
        if(num1<0 && num2>0 && num3>0){
            System.out.println(num2*num3);
        }else if(num1>0 && num2<0 && num3>0){
            System.out.println(num1*num3);
        }else if(num1>0 && num2>0 && num3<0){
            System.out.println(num1*num2);
        }else{
            System.out.println("Te mandaste cualquiera.");
        }
        

        }

    }
