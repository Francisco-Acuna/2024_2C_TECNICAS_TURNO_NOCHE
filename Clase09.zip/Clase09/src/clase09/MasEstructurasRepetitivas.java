

package clase09;


public class MasEstructurasRepetitivas {
    public static void main(String[] args) {
        
        int edad = 18;
        String mensaje;
        
        if(edad>=18){
            mensaje = "Es mayor de edad.";
        }else{
            mensaje = "No es mayor de edad.";
        }
        
        System.out.println(mensaje);
        
        //operador ternario
        mensaje = (edad>=18) ? "Es mayor de edad." : "No es mayor de edad.";
        System.out.println(mensaje);
        
        
        System.out.println("\n**Estructura switch case**");
        
        //supongamos que tenemos que definir un color seg�n el siguiente esquema:
        //1=rojo, 2=azul, 3=celeste, 4=violeta y cualquier otro color = negro
        
        int nro = 2;
        
        if(nro==1){
            System.out.println("rojo");
        }else if(nro==2){
            System.out.println("azul");
        }else if(nro==3){
            System.out.println("celeste");
        }else if(nro==4){
            System.out.println("violeta");
        }else{
            System.out.println("negro");
        }
        
        switch(nro){
            case 1: System.out.println("rojo"); break;
            case 2: System.out.println("azul"); break;
            case 3: System.out.println("celeste"); break;
            case 4: System.out.println("violeta"); break;
            default: System.out.println("negro");
        }
        
        //en las estructuras tradicionales switch case, no es obligatorio el uso 
        //del default
        
        int dia = 2;
        
        switch(dia){
            case 1: System.out.println("El d�a es lunes"); break;
            case 2: System.out.println("El d�a es martes"); break;
            case 3: System.out.println("El d�a es mi�rcoles"); break;
            case 4: System.out.println("El d�a es jueves"); break;
            case 5: System.out.println("El d�a es viernes"); break;
            case 6: System.out.println("El d�a es s�bado"); break;
            case 7: System.out.println("El d�a es domingo"); break;
            default: System.out.println("El d�a no existe"); 
        }
        
        switch(dia){
            case 1, 2, 3, 4, 5:
                System.out.println("Es un d�a de semana"); break;
            case 6, 7:
                System.out.println("Es fin de semana"); break;
            default:
                System.out.println("No es un d�a v�lido");
        }
        
        //la estructura switch no admite expresiones del tipo float, double ni long
        
        //a partir del JDK 12
        //aparecen las expresiones del tipo switch
        //reemplazan los : por ->
        //no se utiliza el break
        
        mensaje = switch(dia){
            case 1-> "lunes";
            case 2-> "martes";
            case 3-> "mi�rcoles";
            case 4-> "jueves";
            case 5-> "viernes";
            case 6-> "s�bado";
            case 7-> "domingo";
            default -> "d�a no v�lido";
        };
        //en las expresiones switch s� es obligatorio el uso del default
        System.out.println(mensaje);
        
        
    }
}
