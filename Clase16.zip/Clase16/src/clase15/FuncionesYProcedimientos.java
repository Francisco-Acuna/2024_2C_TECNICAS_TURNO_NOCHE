

package clase15;


public class FuncionesYProcedimientos {
    public static void main(String[] args) {
        /*
        Funciones y procedimientos
        Las funciones y procedimientos son un bloque de código que 
        contienen una o más instrucciones, al cual podemos invocar
        para que sean ejecutadas.
        Las funciones y procedimientos nos van a ayudar a hacer que
        nuestro código sea más legible y evitar código duplicado.
        */
        
        /*
        Las funciones siempre retornan un valor.
        En su declaración deben indicar el tipo de valor que retornan.
        En su cuerpo deben llevar la sentencia return con el retorno
        del tipo de dato que se indicó en su cabecera.
        */
        
        int numero = devolverNumeroDiez();
        System.out.println(numero);
        
        
    } //cierre del main
    
    //ejemplos de funciones
    public static int devolverNumeroDiez(){
        return 10;
    }
    
    
    
    
} //cierre de la clase
