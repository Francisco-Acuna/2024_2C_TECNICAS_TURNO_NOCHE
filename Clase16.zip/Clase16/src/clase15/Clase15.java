
package clase15;

import java.util.Scanner;


public class Clase15 {

    
    public static void main(String[] args) {
        /*
        1) Una tienda ofrece un descuento del 15% sobre el total de la 
        compra durante el mes de octubre. Dado un mes y un importe, calcular
        cuál es la cantidad que se debe cobrar al cliente.
        */
        
        Scanner teclado = new Scanner(System.in);
//        
//        float descuentoOctubre = 15f;
//        float precioTotal;
//        System.out.println("Por favor ingrese un número que coresponda a"
//                + "un mes del año.");
//        int mes = teclado.nextInt();
//        
//        
//        while(mes<1 || mes>12){
//            System.out.println("Error, el mes debe ser un número entre 1 y 12");
//            System.out.println("Ingrese un número que corresponda a un mes"
//                    + "del daño");
//            mes = teclado.nextInt();
//        }
//        
//        System.out.println("El mes es válido");
//        System.out.println("Por favor, ingrese el precio");
//        float precio = teclado.nextFloat();
//        
//        if(mes==10){
//            System.out.println("Este mes ofrecemos el 15% de descuento sobre"
//                    + " el importe de sus compras");
//            precioTotal = precio - (precio * descuentoOctubre) / 100;
//            System.out.println("Cantidad a cobrar al cliente: " + precioTotal);
//        }else{
//            System.out.println("Cantida a cobrar al cliente: " + precio);
//        }
//        
//        System.out.println("Gracias por su compra, hasta pronto!");
        
        /*
        2) Crear un programa que pida al usuario un número y un símbolo, y 
        dibuje un cuadrado usando ese símbolo. El cuadrado tendrá el tamaño
        que ha indicado el usuario. Por ejemplo, si el usuario introduce 4 
        como tamaño y * como símbolo, deberá escribirse algo como:
        ****
        ****
        ****
        **** 

        */
        
//        System.out.println("Por favor ingrese un número");
//        int numero = teclado.nextInt();
//        teclado.nextLine();
//        System.out.println("Ahora ingrese un símbolo");
//        char simbolo = teclado.next().charAt(0);
//        
//        for(int i=0; i<numero; i++){
//            for(int j=0; j<numero; j++){
//                System.out.print(simbolo);
//            }
//            System.out.println("");
//        }
        
        /*
        3) Se pide representar el algoritmo que nos calcule la suma de los 
        N primeros números naturales. N se leerá por teclado. Ejemplo, si 
        ingresamos 4, hacer: 1+2+3+4 = 10
        */
        
//        int suma = 0;
//        System.out.println("Por favor ingrese un número");
//        int numero = teclado.nextInt();
//        
//        for(int i=1; i<=numero; i++){
//            if(i<numero){
//                System.out.print(i+"+"); 
//                suma+=i;                
//            }else {
//                System.out.print(i);
//                suma+=i;
//            }
//        }
//        
//        System.out.println(" = " + suma);
        
        /*
        4) Crear un programa que visualice la cuenta de los números que 
        son múltiplos de 2 o de 3 que hay entre 1 y 100. 
        */

//        int contador = 0;
//        for(int i=1; i<=100; i++){
//            if(i%2==0 || i%3==0) contador++;            
//        }
//        
//        System.out.println("La cantidad de múltiplos de 2 y de 3 es: " + contador);

        /*
        5) Desarrollar un programa que permita ingresar un número N. Acto 
        seguido, permitir ingresar N números. La computadora muestra cuál 
        fue el mayor y en qué orden apareció. Ejemplo: Se ingresa 5, luego 
        4 8 6 7 5, la computadora muestra: "El mayor es el 8 en la 2° 
        posición".
        */
        
//        System.out.println("Ingrese un número");
//        int numero = teclado.nextInt();
//        int numeroMayor = Integer.MIN_VALUE;
//        int posicion = 1;
//        
//        for(int i=1; i<=numero; i++){
//            System.out.println("Ingrese el " + i + "° número");
//            int numeroIngresado = teclado.nextInt();
//            
//            if(numeroIngresado>numeroMayor){
//                numeroMayor = numeroIngresado;
//                posicion = i;
//            }
//        }
//        
//        System.out.println("El mayor número fue el " + numeroMayor);
//        System.out.println("Que se encontró en la posición " + posicion);
        
        /*
        6) Desarrollar un programa que permita ingresar un número natural. La
        computadora muestra el factorial del número. Ejemplo: Se ingresa 5, la
        computadora muestra: 120.
        */

//        int numeroNatural;
//        int factorial = 1;
//        
//        do {
//            System.out.println("Ingrese el número natural");
//            numeroNatural = teclado.nextInt();
//            if(numeroNatural<=0){
//                System.out.println("Le recuerdo que los números naturales "
//                        + "son mayores a 0.");
//                System.out.println("Por favor, intente nuevamente.");
//            }
//        } while (numeroNatural<=0);
//                
//        for(int i=1; i<=numeroNatural; i++){
//            factorial*=i;
//        }
//        
//        System.out.println(factorial);


        /*
        7) Crear un algoritmo (y su correspondiente diagrama de flujo) que 
        lea números enteros hasta teclear 0, y nos muestre el máximo, el mínimo
        (sin considerar el 0) y la media (promedio) de todos ellos.
        */
        
//        int vueltas = 0;
//        int sumaTotal = 0;
//        int numeroMaximo;
//        int numeroMinimo;
//        int eleccion;
//        
//        
//        System.out.println("Bienvenido. El sistema compara y promedia números "
//                + "hasta que presiones 0");
//        System.out.println("Digite el primer valor");
//        eleccion = teclado.nextInt();
//        numeroMaximo = eleccion;
//        numeroMinimo = eleccion;
//        
//        while(eleccion != 0){
//            vueltas++;
//            sumaTotal += eleccion;
//            System.out.println("Elija el próximo valor a comparar y promediar:");            
//            eleccion = teclado.nextInt();
//            if(eleccion<numeroMinimo && eleccion!=0) numeroMinimo = eleccion;
//            if(eleccion>numeroMaximo && eleccion!=0) numeroMaximo = eleccion;
//        }
//        
//        float promedio = sumaTotal / vueltas;
//        
//        System.out.println("El número mínimo es: " + numeroMinimo);
//        System.out.println("El número máximo es: " + numeroMaximo);
//        System.out.println("El promedio de todos los números es: " + promedio);
        
        /*
        8) Leer tres números que denoten una fecha (día, mes, año). Comprobar 
        que es una fecha válida. Si no es válida escribir un mensaje de error. 
        Si es válida escribir la fecha cambiando el número del mes por su nombre. 
        Ej. si se introduce 1 2 2006, se deberá imprimir “1 de febrero de 2006”. 
        El año debe ser mayor que 0.
        */

//        int anio, mes, dia;
//        System.out.println("Ingrese una fecha válida dd/mm/aaaa");
//        dia = teclado.nextInt();
//        mes = teclado.nextInt();
//        anio = teclado.nextInt();
//        
//        if((dia>0 && dia<=31) && (anio>0)){
//            if(dia>29 && mes==2) {
//                System.out.println("La fecha no es válida");
//            }
//            else if(dia==31 && mes==4 || mes==6 || mes==9 || mes==11){
//                System.out.println("La fecha no es válida");
//            }
//            else {
//                switch(mes){
//                    case 1 : System.out.println(dia + " de Enero del " + anio); break;
//                    case 2 : System.out.println(dia + " de Febrero del " + anio); break;
//                    case 3 : System.out.println(dia + " de Marzo del " + anio); break;
//                    case 4 : System.out.println(dia + " de Abril del " + anio); break;
//                    case 5 : System.out.println(dia + " de Mayo del " + anio); break;
//                    case 6 : System.out.println(dia + " de Junio del " + anio); break;
//                    case 7 : System.out.println(dia + " de Julio del " + anio); break;
//                    case 8 : System.out.println(dia + " de Agosto del " + anio); break;
//                    case 9 : System.out.println(dia + " de Septiembre del " + anio); break;
//                    case 10 : System.out.println(dia + " de Octubre del " + anio); break;
//                    case 11 : System.out.println(dia + " de Noviembre del " + anio); break;
//                    case 12 : System.out.println(dia + " de Diciembre del " + anio); break;
//                    default: System.out.println("La fecha no es válida");
//                }
//            }            
//        }else if(dia>31) System.out.println("La fecha no es válida");

        /*
        9) Imprimir la siguiente figura utilizando la estructura for:
        @@@@
        */
        
//        for(int i=1; i<5; i++){
//            System.out.print("@");
//        }
//        System.out.println("");
        
        /*
        10) Imprimir la siguiente figura utilizando la estructura for:
        @@
        @
        @@
        @ 
        @
        */
        
//        for(int i=1; i<=5; i++){
//            if(i==1 || i==3){
//                System.out.println("@@");
//            }else{
//                System.out.println("@");
//            }
//        }
        
        /*
        11) Imprimir la siguiente figura utilizando la estructura for:
        @@
        @
        @@@
        @@@@
        @@@@@
        */
        
//        for(int i=0; i<5; i++){
//            switch(i){
//                case 0: System.out.println("@@"); break;
//                case 1: System.out.println("@"); break;
//                case 2: System.out.println("@@@"); break;
//                case 3: System.out.println("@@@@"); break;
//                case 4: System.out.println("@@@@@");
//            }
//        }

        /*
        12) Imprimir la siguiente figura utilizando la estructura for:
        @@@@@
        @@@@
        @@@
        @@
        @
        */
        
//        for(int i=5; i>=1; i--){
//            for(int j=1; j<=i; j++){
//                System.out.print("@");
//            }
//            System.out.println("");
//        }
        

        /*
        13) Imprimir la siguiente figura utilizando la estructura for:
        @@
        @
        @@@
        @@@@
        @@@
        @@
        @
        */
        
//        for(int i=0; i<7; i++){
//            switch(i){
//                case 0,5: System.out.println("@@"); break;
//                case 1,6: System.out.println("@"); break;
//                case 2,4: System.out.println("@@@"); break;
//                case 3: System.out.println("@@@@"); 
//            }
//        }

        /*
        14) Imprimir la siguiente figura utilizando la estructura for:
        @@@@@
        @@@
        @@
        @@
        @@@@@
        */
        
        for(int i=0; i<5; i++){
            if(i==0 || i==4) System.out.println("@@@@@");
            else if(i==1) System.out.println("@@@");
            else System.out.println("@@");
        }
        
        
        
        
    }
    
}
