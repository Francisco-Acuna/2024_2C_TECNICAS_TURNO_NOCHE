

package clase12;


public class EstructuraRepetitivaFor {
    public static void main(String[] args) {
        System.out.println("**Estructura for**");
        
        //imprimir los n�meros del 1 al 10 uno al lado del otro
        for(int i=1; i<=10; i++){
            System.out.print(i);
        }
        System.out.println("");
        
        
    }
}
