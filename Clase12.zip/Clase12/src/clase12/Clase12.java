/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase12;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
         /*
        Crear una aplicaci�n que valide el ingreso a una
        plataforma Online Banking a trav�s de una clave Token.
        
        Se debe tener en cuenta lo siguiente:
        * La Clave Token debe ser un n�mero aleatorio
        de 6 d�gitos.
        * El cliente debe ingresar los campos Usuario,
        Contrase�a y Clave Token (todos obligatorios).
        * El campo Usuario no distingue min�sculas
        o may�sculas.
        * El campo Contrase�a es sensible a las
        min�sculas y may�sculas.
        La clave Token aleatoria se le informa al usuario al 
        pedirle que ingrese las credenciales.        
        * El cliente solo posee 3 intentos de logueo. 
	* Si alcanza los 3 intentos fallidos de forma
        consecutiva, la aplicaci�n deber� informar al
        usuario que debe dirigirse a la sucursal del
        banco m�s cercana para poder desbloquear
        sus credenciales.
        * Por cada intento fallido, la aplicaci�n debe
        preguntar al cliente si desea continuar
        colocando las credenciales de manera correcta.
        * Si el cliente coloca las credenciales de forma
        correcta, deber� informar que ha ingresado
        correctamente al Online Banking.
        */
        
        //soluci�n de la alumna Bel�n Gonzalez y Mati
        Scanner teclado = new Scanner(System.in);
        String usuarioCorrecto = "PepE";
        String claveCorrecta = "Adm123";
        int tokenCorrecto = 123456;
        int intentos = 0;
        int correcto = 0;
        System.out.println("Bienvenido a Home Banking su token es " + tokenCorrecto);
        System.out.println("Ingrese el usuario");
        String usuario = teclado.next();
        System.out.println("Ingrese la contrase�a: ");
        String clave = teclado.next();
        System.out.println("Ingrese el token generado");
        int token = teclado.nextInt();
        while(correcto==0){
            if(usuario.equals(usuarioCorrecto) && 
                    clave.equals(claveCorrecta) && 
                    token==tokenCorrecto){
                correcto++;
            }else{
                intentos++;
                if(intentos==3){
                    System.out.println("Usuario bloquedado, debe "
                            + "dirigirse a la sucursal m�s cercana");
                    System.exit(0);
                }else{
                    System.out.println("Los datos ingresados son incorrectos,"
                            + "utiliz� " + intentos + " de 3 intentos");
                    System.out.println("Desea seguir intentando?");
                    System.out.println("1=si\n2=no");
                    int respuesta = teclado.nextInt();
                    if(respuesta==1){
                        System.out.println("Ingrese su usuario");
                        usuario = teclado.next();
                        System.out.println("Ingrese su contrase�a:");
                        clave = teclado.next();
                        System.out.println("Ingrese el token");
                        token = teclado.nextInt();
                    }else{
                        System.exit(0);
                    }                    
                }
            }
        }
        
        System.out.println("Ingreso exitoso puse");
        
        
        
    }
    
}
