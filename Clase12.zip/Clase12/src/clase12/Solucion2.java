

package clase12;

import java.util.Scanner;


public class Solucion2 {
    public static void main(String[] args) {
        //soluci�n propuesta por Elvis y su amigo que est� en M�xico
        
        System.out.println("*** Aplicaci�n On Line Banking ***");
        
        Scanner teclado = new Scanner(System.in);
        int intentosPermitidos = 3;
        int intentos = 0;
        String nombreValido = "Elvis";
        String contrasenaValida = "Passw0rd";
        String nombre, contrasena, claveToken;
        boolean permitirAcceso = false;
        System.out.print("\nIngrese su clave token (6 d�gitos): ");
        claveToken = teclado.nextLine();
        while (claveToken.length() != 6) {
            System.out.println("Error... �La clave token debe ser un "
                    + "n�mero aleatorio de 6 d�gitos");
            claveToken = teclado.nextLine();
        }
        
        System.out.println("\nLa clave token es v�lida -.*\n\n "
                + "*** B I E N V E N I D O ***");
        System.out.println("Ingrese las crecenciales para acceder "
                + "al On Line Banking");
        while (!permitirAcceso && intentos<intentosPermitidos) {
            System.out.println("Ingrese su usuario");
            nombre = teclado.nextLine();
            System.out.println("Ingrese su contrase�a");
            contrasena = teclado.nextLine();
            System.out.println("Su clave token es: " + claveToken);
            
            if(nombre.equalsIgnoreCase(nombreValido) && 
                    contrasena.equals(contrasenaValida)){
                permitirAcceso = true;
                System.out.println("Ha ingresado correctamente al On Line Banking");
            }else{
                intentos++;
                System.out.println("Credenciales incorrectas. Intentos "
                        + "restantes " + (intentosPermitidos-intentos));
                if(intentos<3){
                    System.out.println("Desea continuar ingresando las credenciales "
                            + "de manera correcta?");
                    System.out.println("Presione s para continuar o cualquier "
                            + "otra tecla para salir");
                    String letra = teclado.nextLine().toLowerCase();
                    if(!letra.equals("s")){
                        System.out.println("Saliendo de la plataforma On Line "
                                + "Banking. Hasta pronto!");
                        break;
                    }
                }else{
                    System.out.println("Ha alcanzado el l�mite de intentos "
                            + "fallidos, dir�jase a la sucursal del banco "
                            + "m�s cercana para desbloquear sus credenciales");
                }
            }
                
        }
 
        
    }
}
