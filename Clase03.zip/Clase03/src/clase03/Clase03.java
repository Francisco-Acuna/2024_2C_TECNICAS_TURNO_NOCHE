/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase03;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        ######################################
            M�S TIPOS DE DATOS PRIMITIVOS
        ######################################
        */
        
        // boolean
        // ocupa 1 byte
        // almacena los valores de true y false
        boolean l = true;
        boolean m = false;
        System.out.println(l);
        System.out.println(m);
        
        
        // char
        //ocupa 2 bytes
        //almacena un entero que representa un caracter de la tabla unicode
        char n = 65;
        System.out.println(n);
        //si a una letra may�scula, le sumamos 32, se pasa a min�scula
        n += 32;
        System.out.println(n);
        n = 'f'; //la literal al ser el caracter debe ir entre comillas simples
        System.out.println(n);
        
        
        //String
        //NO ES UN TIPO DE DATO PRIMITIVO
        //ES UNA CLASE
        //representa una cadena de caracteres
        String o = "Hola"; //la literal debe ir entre comillas dobles
        System.out.println(o);
        String p = "Hola, soy una cadena de caracteres!";
        System.out.println(p);
        
        String texto1 = "esta es una frase";
        String texto2 = "ESTA ES OTRA FRASE";
        
        System.out.println(texto1.toUpperCase());
        System.out.println(texto2.toLowerCase());
        
        //concatenaci�n
        //operador +
        String nombre = "Daniel";
        String apellido = "Tello";
        
        System.out.println(nombre);
        System.out.println(apellido);
        System.out.println(nombre + apellido);
        System.out.println(nombre + " " + apellido);
        System.out.println("Su nombre es: " + nombre + " " + apellido);
        
        
        /*
        ######################
            OPERADORES
        ######################
        */
        
        //operadores aritm�ticos
        /*
        + suma
        - resta
        * multiplicaci�n
        / divisi�n
        % m�dulo o resto de la divisi�n
        Son operadores binarios, porque necesitan de 2 operandos.
        Los operandos son num�ricos y el resultado es num�rico.
        */
        
        int nro1 = 10;
        int nro2 = 2;
        
        System.out.print("Suma: ");
        System.out.println(nro1 + nro2); //12
        
        System.out.print("Resta: ");
        System.out.println(nro1 - nro2); //8
        
        System.out.print("Multiplicaci�n: ");
        System.out.println(nro1 * nro2); //20
        
        System.out.print("Divisi�n: ");
        System.out.println(nro1 / nro2); //5
        
        System.out.print("M�dulo o resto: ");
        System.out.println(nro1 % nro2); //0
        
        //Operadores de asignaci�n
        /*
        =   asignaci�n
        +=  suma y asignaci�n
        -=  resta y asignaci�n
        *=  multiplicaci�n y asignaci�n
        /=  divisi�n y asignaci�n
        %=  m�dulo y asignaci�n
        Son operadores binarios.
        Asignan el valor a una variable y se la modifican utilizando una expresi�n
        */
        
        System.out.println(nro1); //10
        nro1 = 12;
        System.out.println(nro1); //12
        nro1 += 2;
        System.out.println(nro1); //14
        nro1 -= 2;
        System.out.println(nro1); //12
        nro1 *= 2;
        System.out.println(nro1); //24
        nro1 /= 2;
        System.out.println(nro1); //12
        nro1 %= 2;
        System.out.println(nro1); //0
        
        
        //Operadores incrementales y decrementales
        /*
        ++ incrementa en 1 el valor de la variable
        -- decrementa en 1 el valor de la variable
        Son operadores unarios, trabajan con un solo operando.
        */
        
        System.out.println(nro1);//0
        nro1 ++;
        System.out.println(nro1); //1
        //nro1++;
        //nro1 = nro1 + 1;
        //nro1 += 1;
        nro1 --;
        System.out.println(nro1); //0
        
    }
    
}
