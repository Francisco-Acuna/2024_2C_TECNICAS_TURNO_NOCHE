/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase01;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("Hola Mundo!");
        
        //Comentarios
        
        //esto es un comentario en l�nea
        //esto es otro comentario en l�nea
        
        /*
        esto es un
        bloque
        de comentarios
        */
        
        /**
         * esto es un comentario
         * del tipo JavaDOc
         * tambi�n es en bloque
         */
        
        
    }
    
}


