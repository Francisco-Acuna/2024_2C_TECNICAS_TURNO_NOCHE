

package clase17;

import java.util.Scanner;


public class FuncionesYProcedimientos {
    public static void main(String[] args) {
        /*
        Funciones y procedimientos
        Las funciones y procedimientos son un bloque de código que 
        contienen una o más instrucciones, al cual podemos invocar
        para que sean ejecutadas.
        Las funciones y procedimientos nos van a ayudar a hacer que
        nuestro código sea más legible y evitar código duplicado.
        */
        
        /*
        Las funciones siempre retornan un valor.
        En su declaración deben indicar el tipo de valor que retornan.
        En su cuerpo deben llevar la sentencia return con el retorno
        del tipo de dato que se indicó en su cabecera.
        */
        
        int numero = devolverNumeroDiez();
        System.out.println(numero);
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese un número:");
        int primerNumero = teclado.nextInt();
        System.out.println("Ingrese otro número:");
        int segundoNumero = teclado.nextInt();
        
        int resultado = sumarDosNumerosEnteros(primerNumero, segundoNumero);
        System.out.println("La suma dio como resultado: " + resultado);
        resultado = sumarDosNumerosEnteros(10, 22);
        System.out.println(resultado);
        resultado = sumarDosNumerosEnteros(27, devolverNumeroDiez());
        System.out.println(resultado);
        
        System.out.println(esPar(15));
        
        //Procedimientos
        /*
        Los procedimientos no retornan valor.
        En su declaración deben llevar la palabra reservada void, para
        indicar que no llevan retorno.
        */
        
        saludar();
        
        System.out.println("Ingrese su nombre");
        String nombreUsuario = teclado.next();
        saludarNombre(nombreUsuario);
        saludarNombre("Mateo");
        
        System.out.println("Ingrese la base del rectángulo:");
        float base = teclado.nextFloat();
        System.out.println("Ingrese la altura del rectángulo:");
        float altura = teclado.nextFloat();
        calcularAreaRectangulo(base, altura);
        System.out.println(calcularAreaRectangulo2(base, altura));
        
        int num1 = 10;
        int num2 = 30;
        nombreUsuario = "Carlos";
        
        sumarParImpar(num1, num2, nombreUsuario);
        
    } //cierre del main
    
    //ejemplos de funciones
    public static int devolverNumeroDiez(){
        return 10;
    }
    
    public static int sumarDosNumerosEnteros(int numero1, int numero2){
        int resultado = numero1 + numero2;
        return resultado;
    }
    
    public static boolean esPar(int numero){
//        if(numero%2 == 0){
//            return true;
//        }else{
//            return false;
//        }
        
        return numero%2 == 0;
        
    }
    
    
    //procedimientos
    public static void saludar(){
        System.out.println("Hola Mundo!");
    }
    
    public static void saludarNombre(String nombre){
        System.out.println("Hola " + nombre);
    }
    
    public static void calcularAreaRectangulo(float base, float altura){
        float area = base * altura;
        System.out.println("El área del rectángulo es: " + area);
    }
    
    //mismo ejemplo anterior pero con función
    public static float calcularAreaRectangulo2(float base, float altura){
        float area = base * altura;
        return area;
    }
    
    //ejemplo de anidados o reutilización
    
    /**
     * El método recibe dos números enteros. Los suma e indica si la suma dio
     * par o impar. Por otro lado, saluda al nombre del usuario que recibió
     * como parámetro.
     * @param numero1
     * @param numero2
     * @param nombre 
     */
    public static void sumarParImpar(int numero1, int numero2, String nombre){
        saludarNombre(nombre);
        if(esPar(sumarDosNumerosEnteros(numero1, numero2))){
            System.out.println("La suma es par");
        }else{
            System.out.println("La suma es impar");
        }
    }
    
    
} //cierre de la clase
