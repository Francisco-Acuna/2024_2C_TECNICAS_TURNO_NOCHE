function resetear() {
    document.getElementById("numero1").value = "";
    document.getElementById("numero2").value = "";
    document.getElementById("resultado").value = "";
    document.getElementById("resultado").style = ""; 
}


function calcular(operacion) {
    let nro1 = parseFloat(document.getElementById("numero1").value);
    let nro2 = parseFloat(document.getElementById("numero2").value);

    let resultado;
    switch (operacion) {
        case "sumar":
            resultado = nro1 + nro2; break;
        case "restar":
            resultado = nro1 - nro2; break;
        case "multiplicar":
            resultado = nro1 * nro2; break;
        case "dividir":
            resultado = nro2 !== 0 ? nro1 / nro2 : "Error / 0 !"; break;
    }

    document.getElementById("resultado").value = resultado;
    cambiarColorResultado(resultado);


    // Llamada para agregar al historial
    agregarAlHistorial(operacion, nro1, nro2, resultado);
}


function agregarAlHistorial(operacion, nro1, nro2, resultado) {
    const historial = document.getElementById("historial");
    const item = document.createElement("li");
    item.className = "list-group-item";
    
    let simbolo;
    switch (operacion) {
        case "sumar": simbolo = "+"; break;
        case "restar": simbolo = "-"; break;
        case "multiplicar": simbolo = "×"; break;
        case "dividir": simbolo = "÷"; break;
    }

    if (isNaN(resultado) || resultado === "Error / 0 !") {
        item.innerText = `\u26A0 Operación no válida: revise las entradas.`;
    } else {
        item.innerText = `${nro1} ${simbolo} ${nro2} = ${resultado}`;
    }
    
    historial.appendChild(item);
}

function cambiarColorResultado(resultado) {
    const campoResultado = document.getElementById("resultado");

    if (resultado === "Error / 0 !" || isNaN(resultado)) {
        campoResultado.style.backgroundColor = "red";
        campoResultado.style.color = "white";
    } else if (resultado < 0) {
        campoResultado.style.backgroundColor = "blue";
        campoResultado.style.color = "white";
    } else {
        campoResultado.style.backgroundColor = "lightgreen";
        campoResultado.style.color = "black";
    }
}

