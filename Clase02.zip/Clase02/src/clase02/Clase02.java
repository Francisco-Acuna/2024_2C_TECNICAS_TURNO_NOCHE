/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase02;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        System.out.println("Hola Mundo!"); //es una sentencia
        //una sentencia es una orden que le damos al programa
        //para que realice una tarea espec�fica
        //las sentencias finalizan con ;
        //el ; es el separador de sentencias
        
        //impresi�n con salto de l�nea
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
        System.out.println("4");
        System.out.println("5");
        
        //impresi�n sin salto de l�nea
        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.print("4");
        System.out.print("5");
        
        System.out.println("");
        
        /*
        %%%%%%%%%%%%%%%%%%%%%%
            VARIABLES
        %%%%%%%%%%%%%%%%%%%%%%
        */
        
        /*
        Una variable es un nombre que se asocia con una porci�n de la memoria
        del ordenador, en donde se guarda el valor asignado a esa variable.
        Las variables deben declararse antes de usarlas.
        La declaraci�n es una sentencia en la que figura el tipo de dato
        asociado a esa variable y el nombre asignado.
        */
        
        int a; //es una declaraci�n de variable
        //se indica el tipo de dato de la variable y el nombre
        a = 2; //asignaci�n de valor a la variable
        int b = 3; //declaraci�n y asignaci�n en l�nea
        a = 4; //cambio de valor a la variable
        
//       a = "hola";  error, no puedo guardar otro tipo de dato
//        int a; error, la variable a, ya est� declarada

        int c=12, d=32, e=42; //declaraci�n y asignaci�n m�ltiple en l�nea
        
        //una variable puede tener una �nica declaraci�n
        //e innumerables valores, siempre que sean del mismo tipo de dato.
        
        /*
        %%%%%%%%%%%
        CONSTANTES
        %%%%%%%%%%%
        */
        
        /*
        Son similares a las variables, porque representan un espacio en memoria
        llevan un identificador (nombre) y un tipo de dato asociado.
        Pero la principal diferencia es que su valor no se puede cambiar.
        En su declaraci�n debe llevar la palabra reservada FINAL
        Y por convenci�n su identificador debe ir en may�sculas.
        */
        
        final double PI = 3.14;
//        PI = 3.15; error, no se puede cambiar el valor de la constante

        /*
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            TIPOS DE DATOS PRIMITIVOS
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        */
        
        // byte
        //ocupa 1 byte y representa un n�mero entero entre -128 y 127
        byte f = 100;
        System.out.println(f);

        // short
        //ocupa 2 bytes
        //representa un n�mero entero entre -32.768 y 32.767
        short g = -32768;
        System.out.println(g);
        
        
        // int
        //ocupa 4 bytes
        //representa un n�mero entero entre -2.147.483.648 y 2.147.483.647
        int h = 1315135135;
        //no se utilizan los puntos para separar los n�meros
        System.out.println(h);
        
        // long
        //ocupa 8 bytes
        //representa un valor muy grande, es el m�s grande de todos
        long i = 1231463154651351L;
        //los tipo de dato long deben llevar una L al final de la literal
        //por convenci�n utilizamos la L may�scula
        
        // float
        //ocupa 4 bytes y tiene una precisi�n de 32 bits
        float j = 14.25f; //debe llevar una f al final de la literal
        //los decimales se separan con punto
        System.out.println(j);
        
        // double
        //ocupa 8 bytes y tiene una precisi�n de 64 bits
        double k = 23.45; //no lleva letra al final de la literal
        System.out.println(k);
        
        //diferencia entre float y double
        float fl = 10f;
        double dl = 10;
        System.out.println(fl / 3);
        System.out.println(dl / 3);
        
        
        
    }
    
}
