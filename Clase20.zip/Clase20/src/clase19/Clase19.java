
package clase19;

import java.util.Arrays;


public class Clase19 {


    public static void main(String[] args) {
        //si tuviéramos que guardar varios valores enteros en variables
        int numero1 = 10;
        int numero2 = 30;
        int numero3 = 76;
        int numero4 = 125;
        
        /*
        Podemos generar un conjunto de variables que tengan un mismo nombre 
        que las agrupe a todas. 
        Podemos acceder a cada variable por medio del índice.
        El índice comienza en cero.
        Optimizamos la lectura de la información para acceder por un mismo
        nombre a distintas variables y no por el nombre de cada una de ellas.
        */
        
        System.out.println("Arreglos, Arrays o vectores");
        
        /*
            tipoDeDato[] identificador; --> declaración
            tipoDeDato identificador[]; --> declaración
            identificador = new tipoDeDato[n]; --> definición de longitud
            la longitud es la cantidad de elementos que tendrá
        */
        
        float[] temperaturas; // declaración
        temperaturas = new float[10]; //defino la longitud en 10
        float temperaturas2[]; //declaración
        temperaturas2 = new float[12]; //defino la longitud en 12
        String[] nombres = new String[5];
        //declaración del arreglo y definición de longitud
        
        //asignación de valores a un arreglo
        temperaturas[0] = 25.32f;
        temperaturas[1] = 12.56f;
//        temperaturas[2] = "Jose"; error, no es del mismo tipo de dato
        
        nombres[3] = "Juan";
//        nombres[5] = "María"; error, no existe el índice 5 para una longitud de 5

        //leer contenido de un índice
        System.out.println(temperaturas[0]);
        System.out.println(nombres[3]);
        
        //inicialización
        int[] numeros = {12, 59, 87, 129, 0};
        //declaración e inicialización del arreglo
        
        //mostrar el contenido del arreglo
        System.out.println(numeros);
        //no muestra el contenido, es una referencia
        
//        System.out.println(numeros[0]);
//        System.out.println(numeros[1]);
//        System.out.println(numeros[2]);
//        System.out.println(numeros[3]);
//        System.out.println(numeros[4]);

        for(int i=0; i<5; i++){
            System.out.println(numeros[i]);
        }
        

        for(int i=0; i<5; i++){
            System.out.println("El valor en el índice " + i +" es: " + numeros[i]);
        }        
        
        //longitud de un vector
        System.out.println("Longitud del vector numeros");
        System.out.println(numeros.length);
        
        for(int i=0; i<numeros.length; i++){
            System.out.println(numeros[i]);
        }
        
        //copias de arreglos
        char[] origen = {'a', 'b', 'c', 'x', '@'};
        
        //creamos un vector de destino con la misma longitud que el origen
        char[] destino = new char[origen.length];
        
        //recorremos los vectores
        System.out.println("vector de origen");
        for(int i=0; i<origen.length; i++){
            System.out.println(origen[i]);
        }
 
        System.out.println("vector de destino");
        for(int i=0; i<destino.length; i++){
            System.out.println(destino[i]);
        }
        
//        System.out.println("Copia del arreglo asignado valor por posición de a uno");
//        destino[0] = origen[0];
//        destino[1] = origen[1];
//        destino[2] = origen[2];
//        destino[3] = origen[3];
//        destino[4] = origen[4];
//        
//        //recorremos los vectores
//        System.out.println("vector de origen");
//        for(int i=0; i<origen.length; i++){
//            System.out.println(origen[i]);
//        }
// 
//        System.out.println("vector de destino");
//        for(int i=0; i<destino.length; i++){
//            System.out.println(destino[i]);
//        }
        
//        System.out.println("Copia del arreglo con for");
//        for(int i=0; i<origen.length; i++){
//            destino[i] = origen[i];
//        }
//        
//        //recorremos los vectores
//        System.out.println("vector de origen");
//        for(int i=0; i<origen.length; i++){
//            System.out.println(origen[i]);
//        }
// 
//        System.out.println("vector de destino");
//        for(int i=0; i<destino.length; i++){
//            System.out.println(destino[i]);
//        }
        
        System.out.println("Copia del arreglo utilizando arraycopy()");
        System.arraycopy(origen, 0, destino, 0, origen.length);
        //arraycopy() es un método de la clase System que se utiliza para copiar
        //vectores
        //recibe 5 parámetros
        //el primero es el vector de origen, el segundo la posición del origen
        //el tercero es el vector de destino, el cuarto es la posición de destino
        //el quinto es la longitud, es decir, la cantidad de elementos que va
        //a copiar.       
        
        //recorremos los vectores
        System.out.println("vector de origen");
        for(int i=0; i<origen.length; i++){
            System.out.println(origen[i]);
        }
 
        System.out.println("vector de destino");
        for(int i=0; i<destino.length; i++){
            System.out.println(destino[i]);
        }
        System.out.println("\n********************************\n");
        //ordenar un vector
        int[] vector = {4, 56, 73, 12, 38, 1, 60, 7};
        Arrays.sort(vector);
        
        for(int i=0; i<vector.length; i++){
            System.out.println(vector[i]);
        }
        
        String[] palabras = {"ggg", "aaa", "ffff"};
        Arrays.sort(palabras);
        for(int i=0; i<palabras.length; i++){
            System.out.println(palabras[i]);
        }
        
        //foreach aparece a partir del JDK 5
        //es una simplificación del for tradicional
        /*
        for(tipo_de_dato elemento : colección){
            cuerpo del foreach - sentencias que se ejecutan en 
            cada iteración.
        }
        */
        //ya no necesitamos preocuparnos por el índice, ni por el límite,
        //ni por el avance
        System.out.println("");
        System.out.println("Recorrido foreach");
        for(int v:vector) System.out.println(v);
        
        //promedio
        int[] datos = {12, 35, 59, 68, 12};
        float suma = 0;
        
//        for(int i=0; i<datos.length; i++){
//            suma += datos[i];
//        }
        
        //con foreach
        for(int d:datos) suma+=d;
        
        float promedio = suma / datos.length;
        System.out.println("El promedio es: " + promedio);
        
        //cálculo del mayor
        int mayor = datos[0];
        for(int d:datos) if(d>mayor) mayor=d;
        System.out.println("El mayor es: " + mayor);
 
        //cálculo del menor
        int menor = datos[0];
        for(int d:datos) if(d<menor) menor=d;
        System.out.println("El menor es: " + menor);
        
    }
    
}
